# PIAttributeLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**attributes** | **string**
**element** | **string**
**event_frame** | **string**
**parent** | **string**
**template** | **string**
**interpolated_data** | **string**
**recorded_data** | **string**
**plot_data** | **string**
**summary_data** | **string**
**value** | **string**
**end_value** | **string**
**point** | **string**
**categories** | **string**
**enumeration_set** | **string**
**enumeration_values** | **string**
**trait** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
