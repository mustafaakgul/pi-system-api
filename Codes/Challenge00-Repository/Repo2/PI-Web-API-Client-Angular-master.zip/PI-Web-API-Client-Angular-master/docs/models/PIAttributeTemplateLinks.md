# PIAttributeTemplateLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**attribute_templates** | **string**
**element_template** | **string**
**parent** | **string**
**categories** | **string**
**trait** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
