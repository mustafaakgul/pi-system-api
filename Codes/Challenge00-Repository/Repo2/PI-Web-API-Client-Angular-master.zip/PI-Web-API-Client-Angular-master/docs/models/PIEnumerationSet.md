# PIEnumerationSet

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **string**
**id** | **string**
**name** | **string**
**description** | **string**
**path** | **string**
**links** | **[**PIEnumerationSetLinks**](../models/PIEnumerationSetLinks.md)**
**serialize_description** | **boolean**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
