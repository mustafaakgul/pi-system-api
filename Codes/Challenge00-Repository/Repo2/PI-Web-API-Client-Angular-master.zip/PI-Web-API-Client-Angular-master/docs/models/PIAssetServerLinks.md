# PIAssetServerLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**databases** | **string**
**security_identities** | **string**
**security_mappings** | **string**
**unit_classes** | **string**
**analysis_rule_plug_ins** | **string**
**time_rule_plug_ins** | **string**
**security** | **string**
**security_entries** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
