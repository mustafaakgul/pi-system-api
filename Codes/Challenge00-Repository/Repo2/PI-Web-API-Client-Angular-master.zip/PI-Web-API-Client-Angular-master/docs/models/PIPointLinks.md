# PIPointLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**data_server** | **string**
**attributes** | **string**
**interpolated_data** | **string**
**recorded_data** | **string**
**plot_data** | **string**
**summary_data** | **string**
**value** | **string**
**end_value** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
