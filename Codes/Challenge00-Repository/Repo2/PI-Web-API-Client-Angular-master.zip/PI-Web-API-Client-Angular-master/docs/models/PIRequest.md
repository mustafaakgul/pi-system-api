# PIRequest

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**method** | **string**
**resource** | **string**
**request_template** | **[**PIRequestTemplate**](../models/PIRequestTemplate.md)**
**parameters** | **Array<string>**
**headers** | **{ [key: string]: string; }**
**content** | **string**
**parent_ids** | **Array<string>**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
