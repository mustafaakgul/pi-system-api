# PISystemLandingLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**cache_instances** | **string**
**configuration** | **string**
**user_info** | **string**
**versions** | **string**
**status** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
