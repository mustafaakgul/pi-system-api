# PIAnalysisRuleLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**analysis_rules** | **string**
**analysis** | **string**
**analysis_template** | **string**
**parent** | **string**
**plug_in** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
