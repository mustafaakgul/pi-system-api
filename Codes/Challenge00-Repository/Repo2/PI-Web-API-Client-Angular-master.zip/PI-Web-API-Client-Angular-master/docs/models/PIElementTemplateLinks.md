# PIElementTemplateLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**analysis_templates** | **string**
**attribute_templates** | **string**
**database** | **string**
**categories** | **string**
**base_template** | **string**
**default_attribute** | **string**
**security** | **string**
**security_entries** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
