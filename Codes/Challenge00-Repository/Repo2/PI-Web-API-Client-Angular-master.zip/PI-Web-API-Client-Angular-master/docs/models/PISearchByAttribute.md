# PISearchByAttribute

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**search_root** | **string**
**element_template** | **string**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**
**value_queries** | **Array<PIValueQuery>**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
