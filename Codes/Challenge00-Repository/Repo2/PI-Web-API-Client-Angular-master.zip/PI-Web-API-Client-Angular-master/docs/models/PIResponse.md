# PIResponse

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**status** | **number**
**headers** | **{ [key: string]: string; }**
**content** | **any**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
