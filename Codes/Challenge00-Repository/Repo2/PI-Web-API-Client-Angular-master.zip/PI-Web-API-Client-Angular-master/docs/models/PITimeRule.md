# PITimeRule

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **string**
**id** | **string**
**name** | **string**
**description** | **string**
**path** | **string**
**config_string** | **string**
**config_string_stored** | **string**
**display_string** | **string**
**editor_type** | **string**
**is_configured** | **boolean**
**is_initializing** | **boolean**
**merge_duplicated_items** | **boolean**
**plug_in_name** | **string**
**links** | **[**PITimeRuleLinks**](../models/PITimeRuleLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
