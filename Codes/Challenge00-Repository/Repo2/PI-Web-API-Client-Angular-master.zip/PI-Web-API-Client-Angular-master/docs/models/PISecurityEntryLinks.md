# PISecurityEntryLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**securable_object** | **string**
**security_identity** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
