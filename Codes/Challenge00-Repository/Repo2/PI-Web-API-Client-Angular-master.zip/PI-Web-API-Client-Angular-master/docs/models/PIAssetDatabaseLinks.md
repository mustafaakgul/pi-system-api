# PIAssetDatabaseLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**elements** | **string**
**element_templates** | **string**
**event_frames** | **string**
**asset_server** | **string**
**element_categories** | **string**
**attribute_categories** | **string**
**table_categories** | **string**
**analysis_categories** | **string**
**analysis_templates** | **string**
**enumeration_sets** | **string**
**tables** | **string**
**security** | **string**
**security_entries** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
