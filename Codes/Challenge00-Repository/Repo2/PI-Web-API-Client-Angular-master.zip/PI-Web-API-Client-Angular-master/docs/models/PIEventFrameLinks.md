# PIEventFrameLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**attributes** | **string**
**event_frames** | **string**
**database** | **string**
**referenced_elements** | **string**
**primary_referenced_element** | **string**
**parent** | **string**
**template** | **string**
**default_attribute** | **string**
**categories** | **string**
**annotations** | **string**
**interpolated_data** | **string**
**recorded_data** | **string**
**plot_data** | **string**
**summary_data** | **string**
**value** | **string**
**end_value** | **string**
**security** | **string**
**security_entries** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
