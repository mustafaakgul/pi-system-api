# PIAnnotation

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**id** | **string**
**name** | **string**
**description** | **string**
**value** | **any**
**creator** | **string**
**creation_date** | **string**
**modifier** | **string**
**modify_date** | **string**
**links** | **[**PIAnnotationLinks**](../models/PIAnnotationLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
