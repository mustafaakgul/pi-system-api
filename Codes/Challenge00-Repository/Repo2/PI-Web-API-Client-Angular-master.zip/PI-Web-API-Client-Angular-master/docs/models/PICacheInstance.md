# PICacheInstance

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**id** | **string**
**last_refresh_time** | **string**
**will_refresh_after** | **string**
**scheduled_expiration_time** | **string**
**user** | **string**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
