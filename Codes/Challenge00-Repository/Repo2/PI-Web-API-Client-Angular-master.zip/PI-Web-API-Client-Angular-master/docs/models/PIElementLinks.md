# PIElementLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**analyses** | **string**
**attributes** | **string**
**elements** | **string**
**database** | **string**
**parent** | **string**
**template** | **string**
**categories** | **string**
**default_attribute** | **string**
**event_frames** | **string**
**interpolated_data** | **string**
**recorded_data** | **string**
**plot_data** | **string**
**summary_data** | **string**
**value** | **string**
**end_value** | **string**
**security** | **string**
**security_entries** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
