# PIAnalysisLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **string**
**target** | **string**
**database** | **string**
**categories** | **string**
**template** | **string**
**analysis_rule** | **string**
**analysis_rule_plug_in** | **string**
**time_rule** | **string**
**time_rule_plug_in** | **string**
**security** | **string**
**security_entries** | **string**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
