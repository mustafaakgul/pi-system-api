# HomeApi

Method | HTTP request | Description
------------ | ------------- | -------------
[**get**](HomeApi.md#get) | **GET** / | Get top level links for this PI System Web API instance.


# **get**
> get()

Get top level links for this PI System Web API instance.

### Parameters

Name | Type | Description | Notes
------------- | ------------- | ------------- | -------------


### Return type



[[Back to top]](#) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
