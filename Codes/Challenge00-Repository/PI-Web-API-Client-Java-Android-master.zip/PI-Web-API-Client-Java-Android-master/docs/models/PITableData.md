# PITableData

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Columns** | **Map<String, String>**
**Rows** | **List<Map<String, Object>>**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
