# PIAttributeLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**Attributes** | **String**
**Element** | **String**
**EventFrame** | **String**
**Parent** | **String**
**Template** | **String**
**InterpolatedData** | **String**
**RecordedData** | **String**
**PlotData** | **String**
**SummaryData** | **String**
**Value** | **String**
**EndValue** | **String**
**Point** | **String**
**Categories** | **String**
**EnumerationSet** | **String**
**EnumerationValues** | **String**
**Trait** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
