# PICacheInstance

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Id** | **String**
**LastRefreshTime** | **String**
**WillRefreshAfter** | **String**
**ScheduledExpirationTime** | **String**
**User** | **String**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
