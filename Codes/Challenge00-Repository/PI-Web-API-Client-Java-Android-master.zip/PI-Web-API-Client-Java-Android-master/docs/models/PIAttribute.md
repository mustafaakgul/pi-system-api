# PIAttribute

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**WebId** | **String**
**Id** | **String**
**Name** | **String**
**Description** | **String**
**Path** | **String**
**Type** | **String**
**TypeQualifier** | **String**
**DefaultUnitsName** | **String**
**DataReferencePlugIn** | **String**
**ConfigString** | **String**
**IsConfigurationItem** | **Boolean**
**IsExcluded** | **Boolean**
**IsHidden** | **Boolean**
**IsManualDataEntry** | **Boolean**
**HasChildren** | **Boolean**
**CategoryNames** | **List<String>**
**Step** | **Boolean**
**TraitName** | **String**
**Links** | **[**PIAttributeLinks**](../models/PIAttributeLinks.md)**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
