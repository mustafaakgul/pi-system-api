# PIValueQuery

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**AttributeName** | **String**
**AttributeUOM** | **String**
**AttributeValue** | **[**Object**](../models/Object.md)**
**SearchOperator** | **String**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
