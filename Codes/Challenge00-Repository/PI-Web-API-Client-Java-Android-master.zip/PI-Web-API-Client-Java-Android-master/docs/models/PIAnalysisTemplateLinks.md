# PIAnalysisTemplateLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**Database** | **String**
**Categories** | **String**
**AnalysisRule** | **String**
**AnalysisRulePlugIn** | **String**
**TimeRule** | **String**
**TimeRulePlugIn** | **String**
**Target** | **String**
**Security** | **String**
**SecurityEntries** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
