# PIPointLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**DataServer** | **String**
**Attributes** | **String**
**InterpolatedData** | **String**
**RecordedData** | **String**
**PlotData** | **String**
**SummaryData** | **String**
**Value** | **String**
**EndValue** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
