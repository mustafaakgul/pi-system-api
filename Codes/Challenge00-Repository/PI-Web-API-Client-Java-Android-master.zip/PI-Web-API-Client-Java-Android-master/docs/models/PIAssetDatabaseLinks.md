# PIAssetDatabaseLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**Elements** | **String**
**ElementTemplates** | **String**
**EventFrames** | **String**
**AssetServer** | **String**
**ElementCategories** | **String**
**AttributeCategories** | **String**
**TableCategories** | **String**
**AnalysisCategories** | **String**
**AnalysisTemplates** | **String**
**EnumerationSets** | **String**
**Tables** | **String**
**Security** | **String**
**SecurityEntries** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
