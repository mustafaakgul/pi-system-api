# PITimeRule

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**WebId** | **String**
**Id** | **String**
**Name** | **String**
**Description** | **String**
**Path** | **String**
**ConfigString** | **String**
**ConfigStringStored** | **String**
**DisplayString** | **String**
**EditorType** | **String**
**IsConfigured** | **Boolean**
**IsInitializing** | **Boolean**
**MergeDuplicatedItems** | **Boolean**
**PlugInName** | **String**
**Links** | **[**PITimeRuleLinks**](../models/PITimeRuleLinks.md)**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
