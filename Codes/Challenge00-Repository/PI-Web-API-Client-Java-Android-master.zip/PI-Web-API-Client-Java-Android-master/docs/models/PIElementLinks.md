# PIElementLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**Analyses** | **String**
**Attributes** | **String**
**Elements** | **String**
**Database** | **String**
**Parent** | **String**
**Template** | **String**
**Categories** | **String**
**DefaultAttribute** | **String**
**EventFrames** | **String**
**InterpolatedData** | **String**
**RecordedData** | **String**
**PlotData** | **String**
**SummaryData** | **String**
**Value** | **String**
**EndValue** | **String**
**Security** | **String**
**SecurityEntries** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
