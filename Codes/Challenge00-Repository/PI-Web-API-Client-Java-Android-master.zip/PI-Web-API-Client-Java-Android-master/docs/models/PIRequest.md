# PIRequest

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Method** | **String**
**Resource** | **String**
**RequestTemplate** | **[**PIRequestTemplate**](../models/PIRequestTemplate.md)**
**Parameters** | **List<String>**
**Headers** | **Map<String, String>**
**Content** | **String**
**ParentIds** | **List<String>**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
