# PIDataServerLicense

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**AmountLeft** | **String**
**AmountUsed** | **String**
**Name** | **String**
**TotalAmount** | **String**
**Links** | **[**PIDataServerLicenseLinks**](../models/PIDataServerLicenseLinks.md)**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
