# PIEventFrameLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**Attributes** | **String**
**EventFrames** | **String**
**Database** | **String**
**ReferencedElements** | **String**
**PrimaryReferencedElement** | **String**
**Parent** | **String**
**Template** | **String**
**DefaultAttribute** | **String**
**Categories** | **String**
**Annotations** | **String**
**InterpolatedData** | **String**
**RecordedData** | **String**
**PlotData** | **String**
**SummaryData** | **String**
**Value** | **String**
**EndValue** | **String**
**Security** | **String**
**SecurityEntries** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
