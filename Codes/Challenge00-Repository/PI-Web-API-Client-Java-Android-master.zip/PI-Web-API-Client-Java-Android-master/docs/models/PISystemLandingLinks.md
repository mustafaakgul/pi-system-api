# PISystemLandingLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**CacheInstances** | **String**
**Configuration** | **String**
**UserInfo** | **String**
**Versions** | **String**
**Status** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
