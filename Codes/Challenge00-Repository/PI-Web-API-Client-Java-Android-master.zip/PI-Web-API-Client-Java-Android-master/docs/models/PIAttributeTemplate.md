# PIAttributeTemplate

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**WebId** | **String**
**Id** | **String**
**Name** | **String**
**Description** | **String**
**Path** | **String**
**Type** | **String**
**TypeQualifier** | **String**
**DefaultUnitsName** | **String**
**DefaultValue** | **[**Object**](../models/Object.md)**
**DataReferencePlugIn** | **String**
**ConfigString** | **String**
**IsConfigurationItem** | **Boolean**
**IsExcluded** | **Boolean**
**IsHidden** | **Boolean**
**IsManualDataEntry** | **Boolean**
**HasChildren** | **Boolean**
**CategoryNames** | **List<String>**
**TraitName** | **String**
**Links** | **[**PIAttributeTemplateLinks**](../models/PIAttributeTemplateLinks.md)**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
