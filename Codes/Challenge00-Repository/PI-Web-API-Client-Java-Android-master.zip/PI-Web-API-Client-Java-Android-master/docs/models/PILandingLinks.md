# PILandingLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Self** | **String**
**AssetServers** | **String**
**DataServers** | **String**
**Search** | **String**
**System** | **String**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
