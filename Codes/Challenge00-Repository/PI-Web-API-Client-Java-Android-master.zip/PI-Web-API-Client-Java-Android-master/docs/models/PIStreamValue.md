# PIStreamValue

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**WebId** | **String**
**Name** | **String**
**Path** | **String**
**Value** | **[**PITimedValue**](../models/PITimedValue.md)**
**Links** | **[**PIStreamValueLinks**](../models/PIStreamValueLinks.md)**
**WebException** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
