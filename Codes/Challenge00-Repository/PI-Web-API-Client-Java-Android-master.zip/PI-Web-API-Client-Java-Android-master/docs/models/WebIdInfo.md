# WebIdInfo

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**Marker** | **Strng**
**ObjectID** | **UUID**
**ObjectType** | **String**
**OwnerID** | **UUID**
**OwnerType** | **String**
**Path** | **String**
**PointID** | **int**
**ServerID** | **UUID**
**Version** | **int**
**WebIdType** | **WebIdType**


[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
