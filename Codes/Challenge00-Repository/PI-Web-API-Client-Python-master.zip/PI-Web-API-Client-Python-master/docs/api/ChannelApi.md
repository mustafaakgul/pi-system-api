# ChannelApi

Method | HTTP request | Description
------------ | ------------- | -------------
[**instances**](ChannelApi.md#instances) | **GET** /channels/instances | Retrieves a list of currently running channel instances.


# **instances**
> instances()

Retrieves a list of currently running channel instances.

### Parameters

Name | Type | Description | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**PIItemsChannelInstance**](../models/PIItemsChannelInstance.md)

[[Back to top]](#) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
