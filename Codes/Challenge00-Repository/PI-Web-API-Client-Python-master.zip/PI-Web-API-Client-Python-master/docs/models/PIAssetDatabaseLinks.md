# PIAssetDatabaseLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**elements** | **str**
**element_templates** | **str**
**event_frames** | **str**
**asset_server** | **str**
**element_categories** | **str**
**attribute_categories** | **str**
**table_categories** | **str**
**analysis_categories** | **str**
**analysis_templates** | **str**
**enumeration_sets** | **str**
**tables** | **str**
**security** | **str**
**security_entries** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
