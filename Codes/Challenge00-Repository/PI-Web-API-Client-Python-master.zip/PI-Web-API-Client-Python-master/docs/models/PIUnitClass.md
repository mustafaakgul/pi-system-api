# PIUnitClass

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **str**
**id** | **str**
**name** | **str**
**description** | **str**
**canonical_unit_name** | **str**
**canonical_unit_abbreviation** | **str**
**path** | **str**
**links** | **[**PIUnitClassLinks**](../models/PIUnitClassLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
