# PIRequest

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**method** | **str**
**resource** | **str**
**request_template** | **[**PIRequestTemplate**](../models/PIRequestTemplate.md)**
**parameters** | **list[str]**
**headers** | **dict(str, str)**
**content** | **str**
**parent_ids** | **list[str]**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
