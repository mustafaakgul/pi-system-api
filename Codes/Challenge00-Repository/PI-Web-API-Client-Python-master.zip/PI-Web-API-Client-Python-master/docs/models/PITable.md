# PITable

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **str**
**id** | **str**
**name** | **str**
**description** | **str**
**path** | **str**
**category_names** | **list[str]**
**time_zone** | **str**
**convert_to_local_time** | **bool**
**links** | **[**PITableLinks**](../models/PITableLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
