# PIDataServerLicense

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**amount_left** | **str**
**amount_used** | **str**
**name** | **str**
**total_amount** | **str**
**links** | **[**PIDataServerLicenseLinks**](../models/PIDataServerLicenseLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
