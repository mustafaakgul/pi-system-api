# PIAttributeLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**attributes** | **str**
**element** | **str**
**event_frame** | **str**
**parent** | **str**
**template** | **str**
**interpolated_data** | **str**
**recorded_data** | **str**
**plot_data** | **str**
**summary_data** | **str**
**value** | **str**
**end_value** | **str**
**point** | **str**
**categories** | **str**
**enumeration_set** | **str**
**enumeration_values** | **str**
**trait** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
