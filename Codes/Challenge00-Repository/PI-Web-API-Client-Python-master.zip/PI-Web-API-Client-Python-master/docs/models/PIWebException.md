# PIWebException

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**status_code** | **int**
**errors** | **list[str]**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
