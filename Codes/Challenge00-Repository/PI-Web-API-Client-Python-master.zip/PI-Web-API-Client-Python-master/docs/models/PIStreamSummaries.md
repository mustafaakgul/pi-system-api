# PIStreamSummaries

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**web_id** | **str**
**name** | **str**
**path** | **str**
**items** | **list[PISummaryValue]**
**links** | **[**PIStreamSummariesLinks**](../models/PIStreamSummariesLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
