# PIAnnotation

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**id** | **str**
**name** | **str**
**description** | **str**
**value** | **object**
**creator** | **str**
**creation_date** | **str**
**modifier** | **str**
**modify_date** | **str**
**links** | **[**PIAnnotationLinks**](../models/PIAnnotationLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
