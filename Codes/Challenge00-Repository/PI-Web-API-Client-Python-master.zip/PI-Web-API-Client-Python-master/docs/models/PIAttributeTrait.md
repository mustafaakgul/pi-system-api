# PIAttributeTrait

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**name** | **str**
**abbreviation** | **str**
**allow_child_attributes** | **bool**
**allow_duplicates** | **bool**
**is_allowed_on_root_attribute** | **bool**
**is_type_inherited** | **bool**
**is_u_o_m_inherited** | **bool**
**require_numeric** | **bool**
**require_string** | **bool**
**links** | **[**PIAttributeTraitLinks**](../models/PIAttributeTraitLinks.md)**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
