# PIChannelInstance

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**id** | **str**
**start_time** | **str**
**last_message_sent_time** | **str**
**sent_message_count** | **int**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
