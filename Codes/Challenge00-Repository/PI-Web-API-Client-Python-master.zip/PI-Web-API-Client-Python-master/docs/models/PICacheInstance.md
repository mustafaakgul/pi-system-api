# PICacheInstance

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**id** | **str**
**last_refresh_time** | **str**
**will_refresh_after** | **str**
**scheduled_expiration_time** | **str**
**user** | **str**
**web_exception** | **[**PIWebException**](../models/PIWebException.md)**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
