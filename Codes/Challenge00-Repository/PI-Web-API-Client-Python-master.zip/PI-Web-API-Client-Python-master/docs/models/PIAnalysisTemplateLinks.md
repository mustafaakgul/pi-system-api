# PIAnalysisTemplateLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**database** | **str**
**categories** | **str**
**analysis_rule** | **str**
**analysis_rule_plug_in** | **str**
**time_rule** | **str**
**time_rule_plug_in** | **str**
**target** | **str**
**security** | **str**
**security_entries** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
