# PIElementLinks

## Properties
Name | Type | Notes
------------ | ------------- | -------------
**self** | **str**
**analyses** | **str**
**attributes** | **str**
**elements** | **str**
**database** | **str**
**parent** | **str**
**template** | **str**
**categories** | **str**
**default_attribute** | **str**
**event_frames** | **str**
**interpolated_data** | **str**
**recorded_data** | **str**
**plot_data** | **str**
**summary_data** | **str**
**value** | **str**
**end_value** | **str**
**security** | **str**
**security_entries** | **str**

[[Back to Model list]](../../DOCUMENTATION.md#documentation-for-models) [[Back to API list]](../../DOCUMENTATION.md#documentation-for-api-endpoints) [[Back to DOCUMENTATION]](../../DOCUMENTATION.md)
